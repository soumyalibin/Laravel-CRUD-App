@extends('layout')

@section('content')

<style>
    .container {
      max-width: 450px;
    }
    .push-top {
      margin-top: 50px;
    }
</style>

<div class="card push-top">
  <div class="card-header">
    Add Student
  </div>

  <div class="card-body">
   @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div><br />
    @endif
      <form method="post" action="{{ route('students.store') }}">
          <div class="form-group">
              @csrf
              <label for="number">student_number</label>
              <input type="text" class="form-control" name="student_number"/>
          </div>
          <div class="form-group">
              <label for="first_name">first_name</label>
              <input type="text" class="form-control" name="first_name"/>
          </div>
          <div class="form-group">
              <label for="name">last_name</label>
              <input type="text" class="form-control" name="last_name"/>
          </div>
          <div class="form-group">
              <label for="name">Class number</label>
              <select name="classroom_id">
                <option value="1">1</option>
                <option value="2">2</option>
                 <option value="3">3</option>
              </select>
          </div>
          
          <button type="submit" class="btn btn-block btn-danger">Create Student</button>
      </form>
  </div>
</div>
@endsection