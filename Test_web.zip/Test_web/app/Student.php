<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
	
    use HasFactory;
    protected $fillable = ['student_number', 'first_name', 'last_name', 'classroom_id'];
}
