# Student Management System

#Overview

Create student CRUD (create, read, update and delete) operations
Database name-web_db include this floder

* Welcome page start with two links Student and Search
* Add student page has do all validations
* Search page include display student list 


